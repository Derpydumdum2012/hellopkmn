export const Scripts: ModdedBattleScriptsData = {
	gen: 9,
	inherit: 'gen9dlc1',
};
