export const Moves: import('../../../sim/dex-moves').ModdedMoveDataTable = {
	mindblown: {
		inherit: true,
		isNonstandard: "Future",
	},
	photongeyser: {
		inherit: true,
		isNonstandard: "Future",
	},
	plasmafists: {
		inherit: true,
		isNonstandard: "Future",
	},
};
