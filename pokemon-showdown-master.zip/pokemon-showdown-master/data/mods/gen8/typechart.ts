export const TypeChart: import('../../../sim/dex-data').ModdedTypeDataTable = {
	stellar: {
		inherit: true,
		isNonstandard: 'Future',
	},
};
