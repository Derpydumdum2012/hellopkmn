Logs of moderation actions are stored in this directory.
